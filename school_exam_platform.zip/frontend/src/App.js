
import React from 'react';
import Exam from './Exam';
function App() {
  return <Exam examId={1} studentId={1} />;
}
export default App;
