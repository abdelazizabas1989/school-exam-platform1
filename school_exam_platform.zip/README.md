
# School Exam Platform
نسخة جاهزة لمنصة اختبارات إلكترونية
- Backend: Node.js + Express + PostgreSQL
- Frontend: React.js
- تصحيح تلقائي لأسئلة MCQ
